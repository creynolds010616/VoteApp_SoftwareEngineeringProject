﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Transactions;

namespace VotingApp_SoftEngProject
{
    class Candidate
    {
        //private String Election { get; set; }
        String Name { get; set; }
        public String Info { get; set; }
        int votes { get; set; }
        private static int numOfCandidates = 0;

        public int getNumOfCandidates() { return numOfCandidates; }

        public void vote(){ votes++; }
        public void vote(int i) { votes = i; }
        public int getVotes() { return votes; }

        public Candidate()
        {
            this.Name = "";
            this.Info = "";
            votes = 0;
            numOfCandidates++;
        }
        public Candidate(String Name)
        {
            this.Name = Name;
            Info = "";
            votes = 0;
            numOfCandidates++;
        }
        public Candidate(String Name, String Info)
        {
            
            //this.Election = Election;
            this.Name = Name;
            this.Info = Info;
            votes = 0;
            numOfCandidates++;
        }
        public string getNameOfCandidate() { return Name; }
    }
}
