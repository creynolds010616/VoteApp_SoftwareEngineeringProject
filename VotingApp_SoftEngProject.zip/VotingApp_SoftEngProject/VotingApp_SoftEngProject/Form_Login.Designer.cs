﻿namespace VotingApp_SoftEngProject
{
    partial class Form_Login
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLogin = new System.Windows.Forms.Button();
            this.txtBxRich_candidateInfo = new System.Windows.Forms.RichTextBox();
            this.radBtn_candidateA = new System.Windows.Forms.RadioButton();
            this.radBtn_candidateB = new System.Windows.Forms.RadioButton();
            this.radBtn_candidateC = new System.Windows.Forms.RadioButton();
            this.groupBox_Candidates = new System.Windows.Forms.GroupBox();
            this.btnVote = new System.Windows.Forms.Button();
            this.groupBox_Candidates.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnLogin
            // 
            this.btnLogin.Location = new System.Drawing.Point(83, 849);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(153, 51);
            this.btnLogin.TabIndex = 0;
            this.btnLogin.Text = "Fingerprint verification";
            this.btnLogin.UseVisualStyleBackColor = true;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // txtBxRich_candidateInfo
            // 
            this.txtBxRich_candidateInfo.Enabled = false;
            this.txtBxRich_candidateInfo.Location = new System.Drawing.Point(462, 12);
            this.txtBxRich_candidateInfo.Name = "txtBxRich_candidateInfo";
            this.txtBxRich_candidateInfo.Size = new System.Drawing.Size(1329, 721);
            this.txtBxRich_candidateInfo.TabIndex = 1;
            this.txtBxRich_candidateInfo.Text = "";
            // 
            // radBtn_candidateA
            // 
            this.radBtn_candidateA.AutoSize = true;
            this.radBtn_candidateA.Location = new System.Drawing.Point(42, 38);
            this.radBtn_candidateA.Name = "radBtn_candidateA";
            this.radBtn_candidateA.Size = new System.Drawing.Size(130, 19);
            this.radBtn_candidateA.TabIndex = 2;
            this.radBtn_candidateA.TabStop = true;
            this.radBtn_candidateA.Text = "George Washington";
            this.radBtn_candidateA.UseVisualStyleBackColor = true;
            // 
            // radBtn_candidateB
            // 
            this.radBtn_candidateB.AutoSize = true;
            this.radBtn_candidateB.Location = new System.Drawing.Point(42, 63);
            this.radBtn_candidateB.Name = "radBtn_candidateB";
            this.radBtn_candidateB.Size = new System.Drawing.Size(102, 19);
            this.radBtn_candidateB.TabIndex = 3;
            this.radBtn_candidateB.TabStop = true;
            this.radBtn_candidateB.Text = "Barack Obama";
            this.radBtn_candidateB.UseVisualStyleBackColor = true;
            // 
            // radBtn_candidateC
            // 
            this.radBtn_candidateC.AutoSize = true;
            this.radBtn_candidateC.Location = new System.Drawing.Point(42, 88);
            this.radBtn_candidateC.Name = "radBtn_candidateC";
            this.radBtn_candidateC.Size = new System.Drawing.Size(74, 19);
            this.radBtn_candidateC.TabIndex = 4;
            this.radBtn_candidateC.TabStop = true;
            this.radBtn_candidateC.Text = "John Doe";
            this.radBtn_candidateC.UseVisualStyleBackColor = true;
            // 
            // groupBox_Candidates
            // 
            this.groupBox_Candidates.Controls.Add(this.radBtn_candidateA);
            this.groupBox_Candidates.Controls.Add(this.radBtn_candidateC);
            this.groupBox_Candidates.Controls.Add(this.radBtn_candidateB);
            this.groupBox_Candidates.Location = new System.Drawing.Point(43, 29);
            this.groupBox_Candidates.Name = "groupBox_Candidates";
            this.groupBox_Candidates.Size = new System.Drawing.Size(276, 156);
            this.groupBox_Candidates.TabIndex = 5;
            this.groupBox_Candidates.TabStop = false;
            this.groupBox_Candidates.Text = "Candidates";
            this.groupBox_Candidates.Visible = false;
            // 
            // btnVote
            // 
            this.btnVote.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnVote.Location = new System.Drawing.Point(554, 801);
            this.btnVote.Name = "btnVote";
            this.btnVote.Size = new System.Drawing.Size(515, 123);
            this.btnVote.TabIndex = 6;
            this.btnVote.Text = "Vote";
            this.btnVote.UseVisualStyleBackColor = true;
            this.btnVote.Visible = false;
            this.btnVote.Click += new System.EventHandler(this.btnVote_Click);
            // 
            // Form_Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1904, 1041);
            this.Controls.Add(this.btnVote);
            this.Controls.Add(this.groupBox_Candidates);
            this.Controls.Add(this.txtBxRich_candidateInfo);
            this.Controls.Add(this.btnLogin);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Name = "Form_Login";
            this.Text = "WeVote";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form_Login_Load);
            this.groupBox_Candidates.ResumeLayout(false);
            this.groupBox_Candidates.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.RichTextBox txtBxRich_candidateInfo;
        private System.Windows.Forms.RadioButton radBtn_candidateA;
        private System.Windows.Forms.RadioButton radBtn_candidateB;
        private System.Windows.Forms.RadioButton radBtn_candidateC;
        private System.Windows.Forms.GroupBox groupBox_Candidates;
        private System.Windows.Forms.Button btnVote;
    }
}

