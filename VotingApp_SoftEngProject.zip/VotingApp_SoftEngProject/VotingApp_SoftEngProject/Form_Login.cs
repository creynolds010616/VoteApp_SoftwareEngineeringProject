﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VotingApp_SoftEngProject
{
    public partial class Form_Login : Form
    {
        Election Presidential;

        public Form_Login()
        {
            InitializeComponent();
            txtBxRich_candidateInfo.Visible = false;
            radBtn_candidateA.CheckedChanged += new EventHandler(radioButtons_CheckedChanged);
            radBtn_candidateB.CheckedChanged += new EventHandler(radioButtons_CheckedChanged);
            radBtn_candidateC.CheckedChanged += new EventHandler(radioButtons_CheckedChanged);
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            btnLogin.Enabled = false;
            btnLogin.Text = "Verified Voter";
            txtBxRich_candidateInfo.Visible = true;
            groupBox_Candidates.Visible = true;
            btnVote.Visible = true;
            //String f = File.ReadAllText("\\weVote_candidates.xlsx");
            //var data = File(@"C:\Users\cshsb\source\repos\VotingApp_SoftEngProject\VotingApp_SoftEngProject\Resources\weVote_candidatesCSV.csv");

            //while ()
            //{

            //}
            
        }
        private void radioButtons_CheckedChanged(object sender, EventArgs e)
        {
            if (radBtn_candidateA.Checked)
            {
                txtBxRich_candidateInfo.Text = Presidential.getCandidateInfo(0);
            }
            else if (radBtn_candidateB.Checked)
            {
                txtBxRich_candidateInfo.Text = Presidential.getCandidateInfo(1);
            }
            else if (radBtn_candidateC.Checked)
            {
                txtBxRich_candidateInfo.Text = Presidential.getCandidateInfo(2);
            }
        }
        private void Form_Login_Load(object sender, EventArgs e)
        {
            Presidential = new Election("Presidential");
            Presidential.addCandidate("George Washington", "The first president of the United States");
            Presidential.addCandidate("Barrack Obama", "IsMissed");
            Presidential.addCandidate("John Doe", "Generic Info");
        }

        private void btnVote_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Cast vote for this candidate? You will not be able to change your vote later.", "Vote Confirmation", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                if (radBtn_candidateA.Checked) { Presidential.vote(0); }
                else if (radBtn_candidateB.Checked) { Presidential.vote(1); }
                else if (radBtn_candidateC.Checked) { Presidential.vote(2); }
                MessageBox.Show("Your vote has been casted!", "Vote Result");
                groupBox_Candidates.Enabled = false;
                txtBxRich_candidateInfo.Text = Presidential.GetElectionStatistics();
                btnVote.Enabled = false;
            }
            else
            {
                MessageBox.Show("Your vote was not confirmed.", "Vote Result");
            }
        }
    }
}
