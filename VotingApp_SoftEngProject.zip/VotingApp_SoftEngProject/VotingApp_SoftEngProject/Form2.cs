﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace VotingApp_SoftEngProject
{
    public partial class Form2_VoterScreen : Form
    {
        public Form2_VoterScreen()
        {
            InitializeComponent();
        }
    }
}
