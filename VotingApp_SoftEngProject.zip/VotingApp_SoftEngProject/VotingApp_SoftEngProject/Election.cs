﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace VotingApp_SoftEngProject
{
    class Election
    {
        String Name { get; set; }
        List<Candidate> candidates;
        Candidate c;
        
        public Election(String Name)
        {
            this.Name = Name;
            candidates = new List<Candidate>();
        }
        public override string ToString()
        {
            return this.Name + " Election";
        }
        public void addCandidate(string candidateName, string candidateInfo)
        {
            c = new Candidate(candidateName, candidateInfo);
            candidates.Add(c);
        }
        public void vote(int index)
        {
            candidates[index].vote();
        }
        public string GetElectionStatistics()
        {
            string status = "";
            foreach(var v in candidates)
            {
                status += "Candidate " + v.getNameOfCandidate().Trim() + ": " + v.getVotes() + "\n";
            }
            return status;
        }
        public string getCandidateInfo(int index)
        {
            return candidates[index].Info;
        }
    }
}
